package com.msystem.SupermarketManagementSystem.controller;
//
//import com.msystem.SupermarketManagementSystem.dto.ApiResponse;
//import com.msystem.SupermarketManagementSystem.dto.ProductDto;
//import com.msystem.SupermarketManagementSystem.model.Product;
//import com.msystem.SupermarketManagementSystem.service.ProductService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//

import com.msystem.SupermarketManagementSystem.model.Product;
import com.msystem.SupermarketManagementSystem.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
    @RequestMapping("/api/v1/")
public class ProductController{
    @Autowired
    private ProductService productServices;



    @PostMapping("/pro")
    public Product createProduct (@RequestBody Product product) {
        return productServices.createproduct(product);}
    @GetMapping("/pro")
    public List<Product> getAll() {
        return productServices.getall();
    }



//
//@GetMapping("/pro/{id}")
//public Product getProductByid(@PathVariable integer id){return ProductService.getProductByid(id);}
//


//@PutMapping("/pro/{pro_id}")
//    public void updateProduct(@PathVariable Integer id,@RequestBody Product product){
//
//    productServices.updateProduct(id,product);
//}
//@DeleteMapping("/pro/{id}")
//    public void delete(@PathVariable Integer id){productServices.delete(id);}
//



//    @Autowired
//    private  ProductService productService;
//
//    @Autowired
//    public ProductController(ProductService productService) {
//        this.productService = productService;
//    }
////@PostMapping("/purchase")
////public ApiResponse purchase(@RequestParam(name = "userId") Integer userId, @RequestBody List<ProductDto> productList) {
////    return productService.purchaseProducts(userId, productList);
////}
//
//    @GetMapping("/purch")
//    public ApiResponse list() {
//        return productService.findAllProducts();
//    }
//
//    @PostMapping("/purch")
//    public ApiResponse purch(@RequestBody Product product) {
//        return productService.addProduct(product);
//    }
//
//    @PutMapping("/purch/{id}")
//    public ApiResponse update(@RequestBody Product product) {
//        return productService.updateProduct(product);
//    }
//
//    @DeleteMapping("/purch/{id}")
//    public ApiResponse delete(@PathVariable(name = "id") String productId) {
//        return productService.deleteProduct(productId);
//    }
//
//    @GetMapping("/purch/{id}")
//    public ApiResponse getById(@PathVariable(name = "id") String productId) {
//        return productService.getProductById(productId);
//    }
//



}
