package com.msystem.SupermarketManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupermarketManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
